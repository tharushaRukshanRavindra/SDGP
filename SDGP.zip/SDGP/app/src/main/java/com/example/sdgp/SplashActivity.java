package com.example.sdgp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

/**
 *This class is used to create the splash activity
 */
public class SplashActivity extends AppCompatActivity {

    private static int splashScreenTime = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        //setting the window to be full when splash screen is on

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams
        .FLAG_FULLSCREEN);

        //setting content view
        setContentView(R.layout.splash_activity);

        //fade out animation
        Animation fadeOut = new AlphaAnimation(1, 0);
        fadeOut.setInterpolator(new AccelerateInterpolator());
        fadeOut.setStartOffset(600);
        fadeOut.setDuration(2800);
        ImageView image = findViewById(R.id.silentVoice);

        image.setAnimation(fadeOut);

        /**
         * this method takes the splash activity to the second page
         */
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, SecondPage.class);
                startActivity(intent);
            }
        }, splashScreenTime);


    }
}
